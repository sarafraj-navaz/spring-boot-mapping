package com.jsp.springbootmanytomanybi.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.jsp.springbootmanytomanybi.dao.StudentSubjectDao;
import com.jsp.springbootmanytomanybi.dto.Student;

@RestController
public class StudentSubjectController {

	@Autowired
	private StudentSubjectDao dao;
	
	// saveStudentSubject
	@PostMapping(value = "/saveStudentSubject")
	public List<Student> saveStudentSubject(@RequestBody List<Student> students) {
		return dao.saveStudentSubject(students);
	}
}
