package com.jsp.springbootmanytomanybi.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.jsp.springbootmanytomanybi.dto.Student;
import com.jsp.springbootmanytomanybi.repository.StudentRepository;

@Repository
public class StudentSubjectDao {

	@Autowired
	private StudentRepository studentRepository;
	
	//saveStudentSubject
	public List<Student> saveStudentSubject(List<Student> students){
		return studentRepository.saveAll(students);
	}
}
