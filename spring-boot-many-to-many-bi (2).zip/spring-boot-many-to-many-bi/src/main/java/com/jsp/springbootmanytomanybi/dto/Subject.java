package com.jsp.springbootmanytomanybi.dto;

import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToMany;
import lombok.Data;

@Entity
@Data
public class Subject {

	@Id
	private int subjectId;
	private String subjectName;
	private String subjectAuthor;
	
	@ManyToMany(mappedBy = "subjects")
	private List<Student> students;
}
