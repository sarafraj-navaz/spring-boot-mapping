package com.jsp.springbootmanytomanybi.dto;

import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToMany;
import lombok.Data;

@Entity
@Data
public class Student {

	@Id
	private int studentId;
	private String studentName;
	private long studentPhone;
	
	@ManyToMany(cascade = CascadeType.ALL)
	private List<Subject> subjects;
	
}
