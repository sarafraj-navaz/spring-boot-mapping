package com.jsp.springbootmanytomanybi.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.jsp.springbootmanytomanybi.dto.Student;

public interface StudentRepository extends JpaRepository<Student, Integer> {

}
