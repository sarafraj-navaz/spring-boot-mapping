package com.jsp.springbootonetomanybi.response;

public class ResponseStructure {

}
