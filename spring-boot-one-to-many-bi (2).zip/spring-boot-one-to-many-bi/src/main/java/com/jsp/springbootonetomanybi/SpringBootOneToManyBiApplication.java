package com.jsp.springbootonetomanybi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootOneToManyBiApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootOneToManyBiApplication.class, args);
	}

}
