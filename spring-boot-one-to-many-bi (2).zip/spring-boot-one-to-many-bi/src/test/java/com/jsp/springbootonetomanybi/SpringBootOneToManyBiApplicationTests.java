package com.jsp.springbootonetomanybi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootOneToManyBiApplicationTests {

	@Test
	void contextLoads() {
	}

}
