package com.jsp.onetoonespringboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OneToOneSpringBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
